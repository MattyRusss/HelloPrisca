# HelloPrisca
=== Hello Prisca ===

A plugin based on the Hello Dolly WordPress plugin

== Description ==

When activated you will see a randomly generated comment in the upper right of your admin screen on every page.

This is based on the Hello Dolly plugin that comes as a standard install of all WordPress installations. Instead of lyrics to the song Hello, Dolly, this plugin will display a reminder to students on the Digital Practices Unit at the University of Sheffield.

